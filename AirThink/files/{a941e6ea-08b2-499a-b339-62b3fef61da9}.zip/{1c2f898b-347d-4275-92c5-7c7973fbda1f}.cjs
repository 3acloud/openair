const fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict');
const html=fs.readFileSync(__dirname+'/{4d7205ef-757a-4a66-af16-51bab728857e}.html','utf8');
const code=html.match(/<script id="app-code">([\s\S]*?)<\/script>/)[1];
let stored=null,fail=false;const context={localStorage:{getItem:()=>stored,setItem:(k,v)=>{if(fail)throw Error('quota');stored=v}},location:{search:''},URLSearchParams,crypto:require('node:crypto').webcrypto,Date,setTimeout:()=>0,clearTimeout:()=>{},document:{getElementById:()=>({focus(){}})}};
vm.createContext(context);vm.runInContext(code,context);
function fresh(){const app=vm.runInContext('coffeeApp()',context);app.$nextTick=fn=>{};app.$refs={};app.init();return app}
const checks=[];function check(name,fn){fn();checks.push(name)}
check('初始积分 2860，购物袋为空',()=>{const a=fresh();assert.equal(a.points,2860);assert.equal(a.count,0)});
check('大杯价格与规格、同规格合并、刷新恢复',()=>{const a=fresh();a.product=vm.runInContext('PRODUCTS.latte',context);a.size='large';a.add();a.add();assert.equal(a.count,2);assert.equal(a.total,6400);assert.match(a.cart[0].spec,/大杯/);const b=fresh();assert.equal(b.total,6400);assert.equal(b.count,2)});
check('积分抵扣和金额保持整数精度',()=>{const a=fresh();assert.equal(a.used,2860);assert.equal(a.cash,3540);a.usePoints=false;assert.equal(a.used,0);assert.equal(a.cash,6400)});
check('保存失败保留购物袋、积分和当前位置',()=>{const a=fresh();a.sheet='cart';fail=true;a.checkout();assert.equal(a.count,2);assert.equal(a.points,2860);assert.equal(a.orders.length,0);assert.equal(a.sheet,'cart');assert.match(a.error,/保存未完成/);a.remove(0);assert.equal(a.count,2);fail=false});
check('成功提交清空购物袋并恢复订单，积分用完',()=>{const a=fresh();a.checkout();assert.equal(a.count,0);assert.equal(a.points,0);assert.equal(a.orders[0].cash,3540);assert.equal(a.tab,'orders');const b=fresh();assert.equal(b.orders[0].number,'A026');assert.equal(b.points,0);b.product=vm.runInContext('PRODUCTS.americano',context);b.add();assert.equal(b.used,0);assert.equal(b.cash,1800)});
check('蛋糕不包含饮品规格，数量上限、空袋不可提交',()=>{stored=null;const a=fresh();a.product=vm.runInContext('PRODUCTS.cake',context);a.qty=9;a.add();assert.equal(a.cart[0].spec,'一份');a.qty=1;a.add();assert.equal(a.count,9);assert.match(a.error,/最多选/);a.remove(0);a.checkout();assert.equal(a.orders.length,0)});
check('重新读回失败显示错误、扣分不超余额',()=>{stored='broken';const a=fresh();assert.match(a.error,/无法读取/);stored=null;const b=fresh();b.product=vm.runInContext('PRODUCTS.americano',context);b.add();assert.equal(b.used,1800);assert.equal(b.cash,0);b.checkout();assert.equal(b.points,1060);assert.equal(b.orders[0].used,1800)});
console.log(JSON.stringify({passed:checks.length,checks},null,2));
