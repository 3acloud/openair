# 证据文件对应表

| 证据 | 文件 |
|---|---|
| 首次入场录屏 | {d78a45da-a9b8-4982-9e59-d876868a73b6}.mp4 |
| 首次入场 start帧 | {9559c938-90ce-4300-9ecf-35dc82dfc6ef}.jpg |
| 首次入场 mid帧 | {27283591-32a0-4c9e-a3d9-335938bf7952}.jpg |
| 首次入场 end帧 | {e63a5c2f-49ef-486e-bb0a-5c58a99a48e7}.jpg |
| 首次入场截图工具报告 | {f68976d9-9c89-4438-8345-8effa4764719}.json |
| 抽屉状态切换录屏 | {e7f58c8c-7aa1-4d6f-adeb-546928b34093}.mp4 |
| 抽屉状态切换 start帧 | {70e2a7e1-62e5-4629-9453-7c1492971bea}.jpg |
| 抽屉状态切换 mid帧 | {c9bf3399-8245-4fa2-85e4-84fc7b1ffaf9}.jpg |
| 抽屉状态切换 end帧 | {0c628eb8-f846-472a-bdb1-13d9f877aa5d}.jpg |
| 抽屉状态切换截图工具报告 | {c2d129ed-375b-49eb-a5a6-7f8fdc2234b1}.json |
| 加入购物袋反馈录屏 | {e41cc211-30ef-46d4-8a45-30e8564c59b1}.mp4 |
| 加入购物袋反馈 start帧 | {ffb1667b-6824-497e-9755-4ece93ac5223}.jpg |
| 加入购物袋反馈 mid帧 | {f96b6a0b-f08c-4ce3-9e15-8681086e8a69}.jpg |
| 加入购物袋反馈 end帧 | {476c84e7-53e8-4b90-9f64-56cd6f35a7f4}.jpg |
| 加入购物袋反馈截图工具报告 | {e3462335-0353-4718-a922-3211923afa76}.json |
| 完整点单流程录屏 | {267cf6ab-de4c-44ef-a095-7d2fce8d55a5}.mp4 |
| 完整点单流程 start帧 | {2353b0ff-22de-4df5-b19a-500636f6e2fb}.jpg |
| 完整点单流程 mid帧 | {95766514-2a6c-4383-8d8e-61516257ccb6}.jpg |
| 完整点单流程 end帧 | {7ca10c37-3f59-4e2b-9dd3-edb2f8a298e8}.jpg |
| 完整点单流程截图工具报告 | {c2140a64-cb53-41ee-95a1-03236f5cdebb}.json |
| 390x844 idle | {4edca185-7ddf-43ba-b343-1d01a5cff1de}.png |
| 390x844 detail | {493ba93c-cb8c-4ec5-a813-079591cc038a}.png |
| 390x844 cart | {896e2b33-63b0-4baf-ab28-cf2e48594187}.png |
| 390x844 done | {a18e5801-8da7-484d-ae10-81af7104c122}.png |
| 390x844 error | {1c92658a-8ce3-4f45-a2cf-ff986981e2c6}.png |
| 390x844 exhausted | {00b00acd-de07-4b60-a08e-af8b0753917f}.png |
| 320x740 idle | {b727111e-5e7b-4570-9262-04dd69708b5c}.png |
| 320x740 detail | {70002192-9206-4146-a55e-e5640f423cba}.png |
| 320x740 cart | {06419350-b0b0-406a-bd15-86d4c46e9ff0}.png |
| 320x740 done | {4f12c8f9-a595-4419-adab-1e794b4ac6ec}.png |
| 320x740 error | {7268dcec-d027-440c-8caa-b7a3cf623891}.png |
| 320x740 exhausted | {54c86e21-147b-4999-a968-c41fb77a189b}.png |
| 390x844 idle 2×清晰度 | {0b45a350-5443-444f-9082-ac2b26a32c68}.png |
| 390x844 detail 2×清晰度 | {d330c6c8-18e0-494f-ac5c-fe6451851125}.png |
| 390x844 cart 2×清晰度 | {02bd55e9-4467-423b-b5e7-f89070c7155d}.png |
| 390x844 done 2×清晰度 | {f87f76b5-1c52-4a9d-ade3-8cfd42523aa1}.png |
| 最终状态截图报告 | {0510c2d4-d89e-42eb-8371-391908748423}.json |
| 最终动效探测报告 | {b913b5dd-423b-4816-a1bc-844aa61a4224}.json |
