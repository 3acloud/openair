python startweb.py
pause