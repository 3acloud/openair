#!/usr/bin/env node
// SPDX-License-Identifier: MIT
// Copyright (c) 2026 The Bento authors
//
// Generates slides/src/modelkeys.generated.ts — the set of property names the
// bento/slides format defines, read straight off the interfaces in model.ts.
//
//   node scripts/build-modelkeys.mjs           write the file
//   node scripts/build-modelkeys.mjs --check   fail if it is out of date (CI)
//
// WHY GENERATE IT. `validate()` reports keys the format does not define,
// because a typo'd property is ignored silently and the styling just does not
// apply. That check is only worth having if its key list is RIGHT: a stale
// list reports real keys as unknown, and an agent acting on that would delete
// working properties. A hand-maintained copy of model.ts would drift the first
// time somebody adds a field — so it is derived, and CI fails if the committed
// output does not match the source.
//
// Read via the TypeScript AST rather than regex: the interfaces nest (fx, and
// fx.loop is a union of two shapes) and extend, and a regex gets both wrong.

import { readFileSync, writeFileSync } from 'node:fs'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import { createRequire } from 'node:module'

const root = join(dirname(fileURLToPath(import.meta.url)), '..')
const require = createRequire(join(root, 'slides/package.json'))
const ts = require('typescript')

const MODEL = join(root, 'slides/src/model.ts')
const OUT = join(root, 'slides/src/modelkeys.generated.ts')

const src = ts.createSourceFile(MODEL, readFileSync(MODEL, 'utf8'), ts.ScriptTarget.Latest, true)

/** Every interface in model.ts, by name. */
const interfaces = new Map()
src.forEachChild((n) => {
  if (ts.isInterfaceDeclaration(n)) interfaces.set(n.name.text, n)
})

/** Property names declared directly on a type-literal-ish member list. */
const propsOf = (members) =>
  members.filter((m) => ts.isPropertySignature(m) && m.name).map((m) => m.name.getText(src))

/** Property names of an interface, including everything it extends. */
function keysOf(name, seen = new Set()) {
  if (seen.has(name)) return []
  seen.add(name)
  const decl = interfaces.get(name)
  if (!decl) return []
  const out = [...propsOf(decl.members)]
  for (const h of decl.heritageClauses ?? []) {
    for (const t of h.types) out.push(...keysOf(t.expression.getText(src), seen))
  }
  return out
}

/**
 * Keys of a nested property's object type. Unions contribute every member's
 * keys — `fx.loop` is `dash-march | motion-path`, and a document may hold
 * either, so the valid set is their union.
 */
function nestedKeys(ownerName, path) {
  let node = interfaces.get(ownerName)
  for (const step of path) {
    const member = (node?.members ?? []).find(
      (m) => ts.isPropertySignature(m) && m.name?.getText(src) === step,
    )
    if (!member?.type) return []
    node = member.type
  }
  const collect = (t) => {
    if (ts.isTypeLiteralNode(t)) return propsOf(t.members)
    if (ts.isUnionTypeNode(t)) return t.types.flatMap(collect)
    if (ts.isParenthesizedTypeNode(t)) return collect(t.type)
    if (ts.isTypeReferenceNode(t)) {
      const name = t.typeName.getText(src)
      // `Array<{…}>` / `Partial<X>` carry their shape in the type argument
      if ((name === 'Array' || name === 'Partial') && t.typeArguments) return t.typeArguments.flatMap(collect)
      return keysOf(name)
    }
    if (ts.isArrayTypeNode(t)) return collect(t.elementType)
    return []
  }
  return collect(node)
}

const uniq = (a) => [...new Set(a)].sort()

const ELEMENTS = {
  text: 'TextElement',
  shape: 'ShapeElement',
  image: 'ImageElement',
  svg: 'SvgElement',
  chart: 'ChartElement',
  table: 'TableElement',
  media: 'MediaElement',
  embed: 'EmbedElement', // the embed element (model.ts EmbedElement)
  code: 'CodeElement', // added with the schema: it was missing, so the gate dropped pasted code elements
}

const tables = {
  doc: uniq(keysOf('BentoDoc')),
  slide: uniq(keysOf('Slide')),
  comment: uniq(keysOf('Comment')),
  element: Object.fromEntries(
    Object.entries(ELEMENTS).map(([k, iface]) => [k, uniq(keysOf(iface))]),
  ),
  fx: uniq(nestedKeys('ElementBase', ['fx'])),
  fxKen: uniq(nestedKeys('ElementBase', ['fx', 'ken'])),
  fxLoop: uniq(nestedKeys('ElementBase', ['fx', 'loop'])),
  shadow: uniq(keysOf('ShadowSpec')),
  connectorEnd: uniq(keysOf('ConnectorEnd')),
  tableStyle: uniq(keysOf('TableStyle')),
  tableRow: uniq(keysOf('TableRow')),
  tableCell: uniq(keysOf('TableCell')),
  gradient: uniq(keysOf('GradientFill')),
  imageCrop: uniq(keysOf('ImageCrop')),
  // the document's own nested objects — the schema (schema.ts) describes the
  // top level from these, so a field added to the theme reaches the schema
  // the same way a field added to an element does
  size: uniq(nestedKeys('BentoDoc', ['size'])),
  meta: uniq(nestedKeys('BentoDoc', ['meta'])),
  theme: uniq(nestedKeys('BentoDoc', ['theme'])),
  themePalette: uniq(nestedKeys('BentoDoc', ['theme', 'palette'])),
  themeCodePalette: uniq(nestedKeys('BentoDoc', ['theme', 'codePalette'])),
  present: uniq(nestedKeys('BentoDoc', ['present'])),
  font: uniq(nestedKeys('BentoDoc', ['fonts'])),
}

const lit = (v, indent = '  ') =>
  Array.isArray(v)
    ? `[${v.map((s) => JSON.stringify(s)).join(', ')}]`
    : `{\n${Object.entries(v)
        .map(([k, x]) => `${indent}  ${JSON.stringify(k)}: ${lit(x, indent + '  ')},`)
        .join('\n')}\n${indent}}`

const body = `// SPDX-License-Identifier: MIT
// Copyright (c) 2026 The Bento authors
//
// GENERATED by scripts/build-modelkeys.mjs from slides/src/model.ts — do not
// edit. Run \`node scripts/build-modelkeys.mjs\` after changing the format's
// interfaces; CI fails if this file is out of date.
//
// The property names the bento/slides format defines. \`validate()\` reports
// anything outside these sets, because an unknown key is ignored silently and
// a typo just means the styling does not apply.

export const MODEL_KEYS = ${lit(tables)} as const

export type ElementKind = keyof typeof MODEL_KEYS.element
`

const current = (() => {
  try { return readFileSync(OUT, 'utf8') } catch { return null }
})()

if (process.argv.includes('--check')) {
  if (current !== body) {
    console.error(
      'modelkeys.generated.ts is out of date with model.ts.\n' +
      'Run: node scripts/build-modelkeys.mjs',
    )
    process.exit(1)
  }
  const n = Object.values(tables.element).reduce((a, v) => a + v.length, 0)
  console.log(`model keys up to date (${Object.keys(tables.element).length} element types, ${n} keys)`)
} else {
  writeFileSync(OUT, body)
  console.log(`wrote ${OUT}`)
  for (const [k, v] of Object.entries(tables.element)) console.log(`  ${k.padEnd(6)} ${v.length} keys`)
}
